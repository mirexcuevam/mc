import React, { useState, useEffect } from 'react';
import { Timer, Target, TrendingUp, AlertTriangle, UserPlus, Lock, LogIn, Clock } from 'lucide-react';

function App() {
  const [isGenerating, setIsGenerating] = useState(false);
  const [signal, setSignal] = useState<string | null>(null);
  const [isRegistered, setIsRegistered] = useState(false);
  const [isLogin, setIsLogin] = useState(true);
  const [nextSignalTime, setNextSignalTime] = useState<string>('');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
  });

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setIsRegistered(true);
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsRegistered(true);
  };

  const toggleForm = () => {
    setIsLogin(!isLogin);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const generateSignal = () => {
    setIsGenerating(true);
    // Simulated Aviator signal generation with realistic multipliers
    setTimeout(() => {
      const multipliers = [
        '1.35x', '1.88x', '2.15x', '2.54x', '3.21x', '4.12x', 
        '5.67x', '7.32x', '9.45x', '12.88x'
      ];
      const randomSignal = multipliers[Math.floor(Math.random() * multipliers.length)];
      setSignal(randomSignal);
      setIsGenerating(false);
      scheduleNextSignal();
    }, 2000);
  };

  const scheduleNextSignal = () => {
    const now = new Date();
    const minutes = now.getMinutes();
    let nextMinutes;
    
    // Schedule signals every 5 minutes
    if (minutes % 5 === 0) {
      nextMinutes = minutes + 5;
    } else {
      nextMinutes = Math.ceil(minutes / 5) * 5;
    }
    
    const nextTime = new Date(now);
    nextTime.setMinutes(nextMinutes);
    nextTime.setSeconds(0);
    
    setNextSignalTime(nextTime.toLocaleTimeString('pt-BR', { 
      hour: '2-digit', 
      minute: '2-digit' 
    }));
  };

  useEffect(() => {
    scheduleNextSignal();
  }, []);

  if (!isRegistered) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 to-indigo-900 flex items-center justify-center p-4">
        <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 shadow-xl border border-white/20 w-full max-w-md">
          <div className="flex flex-col items-center gap-6">
            <div className="flex items-center gap-3">
              <Target className="w-8 h-8 text-yellow-400" />
              <h1 className="text-2xl font-bold text-white">Elephant Bet</h1>
            </div>
            
            {isLogin ? (
              <form onSubmit={handleLogin} className="w-full space-y-4">
                <div>
                  <label className="block text-white mb-2">Email</label>
                  <div className="relative">
                    <UserPlus className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-12 pr-4 text-white placeholder-gray-400"
                      placeholder="seu@email.com"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-white mb-2">Senha</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                    <input
                      type="password"
                      name="password"
                      value={formData.password}
                      onChange={handleInputChange}
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-12 pr-4 text-white placeholder-gray-400"
                      placeholder="Sua senha"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-4 rounded-xl font-bold text-lg bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-gray-900 transition-all"
                >
                  <div className="flex items-center justify-center gap-2">
                    <LogIn className="w-5 h-5" />
                    <span>Entrar</span>
                  </div>
                </button>

                <p className="text-center text-white mt-4">
                  Não tem uma conta?{' '}
                  <button
                    type="button"
                    onClick={toggleForm}
                    className="text-yellow-400 hover:text-yellow-300 font-semibold"
                  >
                    Cadastre-se
                  </button>
                </p>
              </form>
            ) : (
              <form onSubmit={handleRegister} className="w-full space-y-4">
                <div>
                  <label className="block text-white mb-2">Nome</label>
                  <div className="relative">
                    <UserPlus className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-12 pr-4 text-white placeholder-gray-400"
                      placeholder="Seu nome completo"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-white mb-2">Email</label>
                  <div className="relative">
                    <UserPlus className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-12 pr-4 text-white placeholder-gray-400"
                      placeholder="seu@email.com"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-white mb-2">Senha</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                    <input
                      type="password"
                      name="password"
                      value={formData.password}
                      onChange={handleInputChange}
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-12 pr-4 text-white placeholder-gray-400"
                      placeholder="Sua senha"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-4 rounded-xl font-bold text-lg bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-gray-900 transition-all"
                >
                  Cadastrar
                </button>

                <p className="text-center text-white mt-4">
                  Já tem uma conta?{' '}
                  <button
                    type="button"
                    onClick={toggleForm}
                    className="text-yellow-400 hover:text-yellow-300 font-semibold"
                  >
                    Faça login
                  </button>
                </p>
              </form>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 to-indigo-900 flex items-center justify-center p-4">
      <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 shadow-xl border border-white/20 w-full max-w-md">
        <div className="flex flex-col items-center gap-6">
          {/* Header */}
          <div className="flex items-center gap-3">
            <Target className="w-8 h-8 text-yellow-400" />
            <h1 className="text-2xl font-bold text-white">Sinais Elephant Bet</h1>
          </div>

          {/* Status Card */}
          <div className="w-full bg-white/5 rounded-xl p-4 border border-white/10">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Timer className="w-5 h-5 text-green-400" />
                <span className="text-green-400 font-medium">Status: Online</span>
              </div>
              <TrendingUp className="w-5 h-5 text-green-400" />
            </div>
            <div className="flex items-center gap-2 text-white">
              <Clock className="w-5 h-5" />
              <span>Próximo sinal às: {nextSignalTime}</span>
            </div>
          </div>

          {/* Signal Display */}
          {signal && (
            <div className="w-full bg-green-500/20 rounded-xl p-6 border border-green-500/30">
              <div className="text-center">
                <h2 className="text-xl text-green-400 font-bold mb-2">Sinal Aviator</h2>
                <p className="text-4xl font-bold text-white">{signal}</p>
                <p className="text-green-400 mt-2">Entrada Confirmada</p>
              </div>
            </div>
          )}

          {/* Warning */}
          <div className="flex items-center gap-2 text-yellow-400/80 text-sm">
            <AlertTriangle className="w-4 h-4" />
            <p>Sinais a cada 5 minutos</p>
          </div>

          {/* Generate Button */}
          <button
            onClick={generateSignal}
            disabled={isGenerating}
            className={`w-full py-4 rounded-xl font-bold text-lg transition-all ${
              isGenerating
                ? 'bg-gray-600 cursor-not-allowed'
                : 'bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-gray-900'
            }`}
          >
            {isGenerating ? 'Gerando...' : 'Gerar Sinal'}
          </button>
        </div>
      </div>
    </div>
  );
}

export default App;