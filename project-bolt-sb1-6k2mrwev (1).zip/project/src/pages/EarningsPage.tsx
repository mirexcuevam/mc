import React from 'react';
import { TrendingUp, Users, Music, DollarSign, Share2, Gift } from 'lucide-react';

interface EarningsCardProps {
  title: string;
  value: string;
  change: string;
  icon: React.ReactNode;
  isPositive?: boolean;
}

function EarningsCard({ title, value, change, icon, isPositive = true }: EarningsCardProps) {
  return (
    <div className="bg-purple-900/20 p-6 rounded-lg">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-gray-300 mb-1">{title}</p>
          <h3 className="text-2xl font-bold mb-2">{value}</h3>
          <p className={`flex items-center gap-1 text-sm ${isPositive ? 'text-green-400' : 'text-red-400'}`}>
            <TrendingUp className={`w-4 h-4 ${!isPositive && 'rotate-180'}`} />
            {change}
          </p>
        </div>
        <div className="p-3 bg-purple-800 rounded-lg">
          {icon}
        </div>
      </div>
    </div>
  );
}

function EarningsPage() {
  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Painel de Ganhos</h1>
        <p className="text-gray-300">Acompanhe seus ganhos e estatísticas em tempo real</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        <EarningsCard
          title="Ganhos Totais"
          value="R$ 2.547,90"
          change="+15.3% este mês"
          icon={<DollarSign className="w-6 h-6 text-purple-300" />}
        />
        <EarningsCard
          title="Ouvintes Únicos"
          value="12.849"
          change="+24.5% este mês"
          icon={<Users className="w-6 h-6 text-purple-300" />}
        />
        <EarningsCard
          title="Total de Streams"
          value="45.123"
          change="+18.2% este mês"
          icon={<Music className="w-6 h-6 text-purple-300" />}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-purple-900/20 p-6 rounded-lg">
          <h2 className="text-xl font-bold mb-6">Distribuição de Ganhos</h2>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between mb-2">
                <span>Streams</span>
                <span>R$ 1.523,40</span>
              </div>
              <div className="h-2 bg-purple-800 rounded-full">
                <div className="h-full w-[60%] bg-purple-500 rounded-full"></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between mb-2">
                <span>Doações</span>
                <span>R$ 524,50</span>
              </div>
              <div className="h-2 bg-purple-800 rounded-full">
                <div className="h-full w-[20%] bg-purple-500 rounded-full"></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between mb-2">
                <span>NFTs</span>
                <span>R$ 500,00</span>
              </div>
              <div className="h-2 bg-purple-800 rounded-full">
                <div className="h-full w-[20%] bg-purple-500 rounded-full"></div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-purple-900/20 p-6 rounded-lg">
          <h2 className="text-xl font-bold mb-6">Programa de Recompensas</h2>
          <div className="space-y-6">
            <div className="flex items-start gap-4">
              <div className="p-3 bg-purple-800 rounded-lg">
                <Share2 className="w-6 h-6 text-purple-300" />
              </div>
              <div>
                <h3 className="font-semibold mb-1">Compartilhamento de Receita</h3>
                <p className="text-gray-300 text-sm">50% dos lucros com anúncios são direcionados aos artistas via blockchain</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="p-3 bg-purple-800 rounded-lg">
                <Gift className="w-6 h-6 text-purple-300" />
              </div>
              <div>
                <h3 className="font-semibold mb-1">Bônus para Fãs</h3>
                <p className="text-gray-300 text-sm">Ganhe moedas SoundCycle por cada compartilhamento e interação</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default EarningsPage;