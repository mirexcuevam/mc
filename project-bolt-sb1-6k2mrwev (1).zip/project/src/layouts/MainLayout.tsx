import React, { useState } from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import { Music, Search, Home, Radio, Library, Plus, DollarSign } from 'lucide-react';

function Sidebar() {
  const location = useLocation();
  
  return (
    <div className="w-64 bg-purple-900 text-white p-6 flex flex-col gap-8">
      <div className="flex items-center gap-2">
        <Music className="w-8 h-8" />
        <span className="text-xl font-bold">SoundCycle</span>
      </div>
      
      <nav className="flex flex-col gap-4">
        <Link 
          to="/" 
          className={`flex items-center gap-3 hover:text-purple-300 transition-colors ${location.pathname === '/' ? 'text-purple-300' : ''}`}
        >
          <Home className="w-5 h-5" />
          <span>Início</span>
        </Link>
        <Link 
          to="/earnings" 
          className={`flex items-center gap-3 hover:text-purple-300 transition-colors ${location.pathname === '/earnings' ? 'text-purple-300' : ''}`}
        >
          <DollarSign className="w-5 h-5" />
          <span>Ganhos</span>
        </Link>
        <a href="#" className="flex items-center gap-3 hover:text-purple-300 transition-colors">
          <Search className="w-5 h-5" />
          <span>Buscar</span>
        </a>
        <a href="#" className="flex items-center gap-3 hover:text-purple-300 transition-colors">
          <Library className="w-5 h-5" />
          <span>Sua Biblioteca</span>
        </a>
        <a href="#" className="flex items-center gap-3 hover:text-purple-300 transition-colors">
          <Radio className="w-5 h-5" />
          <span>Rádio</span>
        </a>
      </nav>

      <div className="mt-8">
        <div className="flex items-center gap-2 mb-4">
          <Plus className="w-5 h-5" />
          <span>Criar Playlist</span>
        </div>
        <div className="bg-purple-800 rounded-lg p-4">
          <h3 className="font-semibold mb-2">Músicas Curtidas</h3>
          <p className="text-sm text-purple-300">200 músicas salvas</p>
        </div>
      </div>
    </div>
  );
}

function NowPlaying() {
  const [isPlaying, setIsPlaying] = useState(false);
  
  return (
    <div className="h-24 bg-gradient-to-r from-purple-800 to-purple-900 text-white px-4 flex items-center justify-between">
      <div className="flex items-center gap-4">
        <img 
          src="https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=70&h=70&fit=crop" 
          alt="Cover" 
          className="w-16 h-16 rounded"
        />
        <div>
          <h4 className="font-semibold">Melodia do Verão</h4>
          <p className="text-sm text-purple-300">Maria Santos</p>
        </div>
      </div>
    </div>
  );
}

function MainLayout() {
  return (
    <div className="h-screen flex flex-col text-white">
      <div className="flex-1 flex overflow-hidden">
        <Sidebar />
        <main className="flex-1 overflow-auto">
          <Outlet />
        </main>
      </div>
      <NowPlaying />
    </div>
  );
}

export default MainLayout;