import React, { useState } from 'react';
import { Play, Upload, Pause, Heart, SkipForward, SkipBack, Repeat, Shuffle, Users } from 'lucide-react';

interface Song {
  id: number;
  title: string;
  artist: string;
  duration: string;
  coverUrl: string;
  listeners: number;
  isFavorite?: boolean;
}

const sampleSongs: Song[] = [
  {
    id: 1,
    title: "Melodia do Verão",
    artist: "Maria Santos",
    duration: "3:45",
    coverUrl: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&h=300&fit=crop",
    listeners: 5280,
    isFavorite: true
  },
  {
    id: 2,
    title: "Noite Estrelada",
    artist: "João Silva",
    duration: "4:20",
    coverUrl: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=300&fit=crop",
    listeners: 4890,
    isFavorite: true
  },
  {
    id: 3,
    title: "Ondas do Mar",
    artist: "Ana Costa",
    duration: "3:30",
    coverUrl: "https://images.unsplash.com/photo-1459749411175-04bf5292ceea?w=300&h=300&fit=crop",
    listeners: 5120,
    isFavorite: true
  },
];

function FavoritePlaylist() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [shuffle, setShuffle] = useState(false);
  const [repeat, setRepeat] = useState(false);
  const [currentSongIndex, setCurrentSongIndex] = useState(0);

  const togglePlay = () => setIsPlaying(!isPlaying);
  const toggleShuffle = () => setShuffle(!shuffle);
  const toggleRepeat = () => setRepeat(!repeat);

  const currentSong = sampleSongs[currentSongIndex];

  return (
    <div className="bg-purple-900/20 rounded-lg p-6 mb-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold mb-2">Playlist Favoritas</h2>
          <p className="text-gray-300 flex items-center gap-2">
            <Users className="w-4 h-4" />
            {currentSong.listeners.toLocaleString()} ouvintes hoje
          </p>
        </div>
        <div className="flex items-center gap-4">
          <button 
            className={`p-2 rounded-full ${shuffle ? 'bg-purple-500' : 'hover:bg-purple-800'} transition-colors`}
            onClick={toggleShuffle}
          >
            <Shuffle className="w-5 h-5" />
          </button>
          <button 
            className={`p-2 rounded-full ${repeat ? 'bg-purple-500' : 'hover:bg-purple-800'} transition-colors`}
            onClick={toggleRepeat}
          >
            <Repeat className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="bg-purple-900/30 rounded-lg p-4 mb-6">
        <div className="flex items-center gap-4 mb-4">
          <img 
            src={currentSong.coverUrl} 
            alt={currentSong.title} 
            className="w-20 h-20 rounded-lg"
          />
          <div className="flex-1">
            <h3 className="font-semibold text-lg">{currentSong.title}</h3>
            <p className="text-gray-300">{currentSong.artist}</p>
          </div>
          <Heart className="w-6 h-6 text-purple-500 fill-current" />
        </div>

        <div className="flex flex-col items-center gap-4">
          <div className="w-full bg-purple-800 rounded-full h-1">
            <div className="bg-purple-500 w-1/3 h-full rounded-full"></div>
          </div>
          <div className="flex items-center gap-6">
            <button className="hover:text-purple-300 transition-colors">
              <SkipBack className="w-6 h-6" />
            </button>
            <button 
              className="p-3 bg-purple-500 rounded-full hover:bg-purple-600 transition-colors"
              onClick={togglePlay}
            >
              {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6" />}
            </button>
            <button className="hover:text-purple-300 transition-colors">
              <SkipForward className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>

      <div className="space-y-2">
        {sampleSongs.map((song, index) => (
          <div 
            key={song.id} 
            className={`flex items-center gap-4 p-3 rounded-lg ${
              index === currentSongIndex ? 'bg-purple-800' : 'hover:bg-purple-900/40'
            } transition-colors cursor-pointer`}
            onClick={() => setCurrentSongIndex(index)}
          >
            <img src={song.coverUrl} alt={song.title} className="w-12 h-12 rounded" />
            <div className="flex-1">
              <h4 className="font-semibold">{song.title}</h4>
              <p className="text-sm text-gray-300">{song.artist}</p>
            </div>
            <div className="text-sm text-gray-300 flex items-center gap-3">
              <span className="flex items-center gap-1">
                <Users className="w-4 h-4" />
                {song.listeners.toLocaleString()}
              </span>
              <span>{song.duration}</span>
            </div>
            {song.isFavorite && <Heart className="w-5 h-5 text-purple-500 fill-current" />}
          </div>
        ))}
      </div>
    </div>
  );
}

function HomePage() {
  const [showUploadModal, setShowUploadModal] = useState(false);

  const handleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      console.log('Arquivo selecionado:', files[0].name);
      setShowUploadModal(false);
    }
  };

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-2xl font-bold">Músicas em Alta</h2>
        <button
          onClick={() => setShowUploadModal(true)}
          className="flex items-center gap-2 bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-full transition-colors"
        >
          <Upload className="w-5 h-5" />
          <span>Postar Música</span>
        </button>
      </div>

      <FavoritePlaylist />

      {showUploadModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-purple-900 p-6 rounded-lg shadow-xl max-w-md w-full">
            <h3 className="text-xl font-bold mb-4">Postar Nova Música</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Título da Música</label>
                <input
                  type="text"
                  className="w-full px-3 py-2 bg-purple-800 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                  placeholder="Digite o título"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Arquivo de Música</label>
                <input
                  type="file"
                  accept="audio/*"
                  onChange={handleUpload}
                  className="w-full px-3 py-2 bg-purple-800 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Capa do Álbum</label>
                <input
                  type="file"
                  accept="image/*"
                  className="w-full px-3 py-2 bg-purple-800 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>
              <div className="flex justify-end gap-3 mt-6">
                <button
                  onClick={() => setShowUploadModal(false)}
                  className="px-4 py-2 text-purple-300 hover:text-white transition-colors"
                >
                  Cancelar
                </button>
                <button
                  onClick={() => setShowUploadModal(false)}
                  className="px-4 py-2 bg-purple-600 hover:bg-purple-700 rounded-md transition-colors"
                >
                  Postar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <div>
        <h2 className="text-2xl font-bold mb-4">Recomendados para Você</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {sampleSongs.map(song => (
            <div key={song.id} className="bg-purple-900/20 p-4 rounded-lg hover:bg-purple-900/30 transition-colors cursor-pointer">
              <img src={song.coverUrl} alt={song.title} className="w-full aspect-square rounded-lg mb-4" />
              <h3 className="font-semibold truncate">{song.title}</h3>
              <p className="text-sm text-gray-400 truncate">{song.artist}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default HomePage;