import React, { useState } from 'react';
import { Timer, Target, TrendingUp, AlertTriangle } from 'lucide-react';

function App() {
  const [isGenerating, setIsGenerating] = useState(false);
  const [signal, setSignal] = useState<string | null>(null);

  const generateSignal = () => {
    setIsGenerating(true);
    // Simulated signal generation
    setTimeout(() => {
      const signals = ['2x', '3x', '5x', '10x'];
      const randomSignal = signals[Math.floor(Math.random() * signals.length)];
      setSignal(randomSignal);
      setIsGenerating(false);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 to-indigo-900 flex items-center justify-center p-4">
      <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 shadow-xl border border-white/20 w-full max-w-md">
        <div className="flex flex-col items-center gap-6">
          {/* Header */}
          <div className="flex items-center gap-3">
            <Target className="w-8 h-8 text-yellow-400" />
            <h1 className="text-2xl font-bold text-white">Sinais Elephant Bet</h1>
          </div>

          {/* Status Card */}
          <div className="w-full bg-white/5 rounded-xl p-4 border border-white/10">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Timer className="w-5 h-5 text-green-400" />
                <span className="text-green-400 font-medium">Status: Online</span>
              </div>
              <TrendingUp className="w-5 h-5 text-green-400" />
            </div>
          </div>

          {/* Signal Display */}
          {signal && (
            <div className="w-full bg-green-500/20 rounded-xl p-6 border border-green-500/30">
              <div className="text-center">
                <h2 className="text-xl text-green-400 font-bold mb-2">Sinal Gerado</h2>
                <p className="text-4xl font-bold text-white">{signal}</p>
              </div>
            </div>
          )}

          {/* Warning */}
          <div className="flex items-center gap-2 text-yellow-400/80 text-sm">
            <AlertTriangle className="w-4 h-4" />
            <p>Aguarde 2 minutos entre os sinais</p>
          </div>

          {/* Generate Button */}
          <button
            onClick={generateSignal}
            disabled={isGenerating}
            className={`w-full py-4 rounded-xl font-bold text-lg transition-all ${
              isGenerating
                ? 'bg-gray-600 cursor-not-allowed'
                : 'bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-gray-900'
            }`}
          >
            {isGenerating ? 'Gerando...' : 'Gerar Sinal'}
          </button>
        </div>
      </div>
    </div>
  );
}

export default App;